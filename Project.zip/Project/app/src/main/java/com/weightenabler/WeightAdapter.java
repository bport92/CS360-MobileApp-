package com.weightenabler;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ProductViewHolder> {

    private final List<Weight> weightList;
    private final OnItemClickListener listener;
    private final OnItemDeleteClickListener deleteListener;

    public WeightAdapter(List<Weight> weightList, OnItemClickListener listener, OnItemDeleteClickListener deleteListener) {
        this.weightList = weightList;
        this.listener = listener;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_weight, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final Weight weight = weightList.get(position);
        holder.textViewDateId.setText(weight.getDate());
        holder.textViewWeightId.setText(weight.getWeight());
        holder.textViewGoalId.setText(String.valueOf(weight.getGoal()));

        holder.buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call the method from the activity or fragment to handle the deletion
                if (deleteListener != null) {
                    deleteListener.onItemDelete(weight, position);
                }
            }
        });

        // Set the click listener for the item view
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Use the interface to pass the click event up to the Activity
                if (listener != null) {
                    listener.onItemClick(weight);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    public interface OnItemClickListener {
        void onItemClick(Weight weight);
    }

    public interface OnItemDeleteClickListener {
        void onItemDelete(Weight weight, int position);
    }

    static class ProductViewHolder extends RecyclerView.ViewHolder {
        TextView textViewDateId, textViewWeightId, textViewGoalId;
        Button buttonDelete;

        ProductViewHolder(View itemView) {
            super(itemView);
            textViewDateId = itemView.findViewById(R.id.lblDateId);
            textViewWeightId = itemView.findViewById(R.id.lblWeightId);
            textViewGoalId = itemView.findViewById(R.id.lblGoal);
            buttonDelete = itemView.findViewById(R.id.btnDelete);
        }
    }

    public void removeItem(int position) {
        weightList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, weightList.size());
    }
}