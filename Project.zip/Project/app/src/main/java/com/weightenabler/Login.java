package com.weightenabler;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    private EditText editUser;
    private EditText editPass;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new DatabaseHelper(this);

        editUser = findViewById(R.id.CreateUser); // Corrected ID
        editPass = findViewById(R.id.CreatePass); // Corrected ID
        Button loginButton = findViewById(R.id.loginButton);
        Button createAccountButton = findViewById(R.id.createAccountButton); // Corrected ID

        loginButton.setOnClickListener(v -> {
            String username = editUser.getText().toString().trim();
            String password = editPass.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(Login.this, "Please enter username and password", Toast.LENGTH_LONG).show();
                return;
            }

            if (db.validateUser(username, password)) {
                Intent intent = new Intent(Login.this, weight_track.class);
                startActivity(intent);
            } else {
                Toast.makeText(Login.this, "Invalid Credentials", Toast.LENGTH_LONG).show();
            }
        });

        createAccountButton.setOnClickListener(v -> {
            Intent intent = new Intent(Login.this, createAccount.class); // Corrected class name
            startActivity(intent);
        });
    }
}