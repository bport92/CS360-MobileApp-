package com.weightenabler;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Weight {
    private String date;
    private String weight;
    private int goal;

    public Weight(String date, String weight, int goal) {
        this.date = date;
        this.weight = weight;
        this.goal = goal;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public int getGoal() {
        return goal;
    }

    public void setGoal(int goal) {
        this.goal = goal;
    }
}