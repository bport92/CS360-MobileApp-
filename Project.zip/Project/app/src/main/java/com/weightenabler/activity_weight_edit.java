package com.weightenabler;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class activity_weight_edit extends AppCompatActivity {

    private EditText editDate;
    private EditText editWeight;
    private EditText editGoal;

    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_edit);

        db = new DatabaseHelper(this);

        editDate = findViewById(R.id.editDate);
        editWeight  = findViewById(R.id.editWeight); // Make sure this ID matches your layout
        editGoal = findViewById(R.id.editGoal); // Make sure this ID matches your layout

        Button btnSave = findViewById(R.id.btnUpdateItem);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("WEIGHT_ID")) {
            // If Weight change is passed, it's an edit operation
            loadWeightData(intent);
        }

        btnSave.setOnClickListener(v -> saveWeight());
    }

    private void saveWeight() {
        String date = editDate.getText().toString();
        String weight = editWeight.getText().toString();
        int goal;
        try {
            goal = Integer.parseInt(editGoal.getText().toString());
        } catch (NumberFormatException e) {
            // Handle error where quantity is not an integer
            return;
        }

        Weight newWeight = new Weight(date, weight, goal);
        if (db.checkWeightExists(date)) {
            db.updateWeight(newWeight);
        } else {
            db.addWeight(newWeight);
        }

        finish(); // Close the activity and go back to the previous one
    }

    private void loadWeightData(Intent intent) {
        // Load weight data from the intent and populate the EditText fields
        if (intent != null) {
            String date = intent.getStringExtra("DATE");
            String weight = intent.getStringExtra("WEIGHT");
            int goal = intent.getIntExtra("GOAL", -1); // Default to -1 if not found

            // Populate the fields
            editDate.setText(date);
            editWeight.setText(weight);
            if (goal != -1) {
                editGoal.setText(String.valueOf(goal));
            }
        }
    }
}
