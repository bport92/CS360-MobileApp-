package com.weightenabler;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;
import android.Manifest;
import android.widget.Switch;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class weight_track extends AppCompatActivity implements WeightAdapter.OnItemClickListener, WeightAdapter.OnItemDeleteClickListener {

    private RecyclerView recyclerView;
    private WeightAdapter weightAdapter;
    private DatabaseHelper db;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch smsSwitch;
    private static final int PERMISSION_SEND_SMS = 123;
    private static final int YOUR_GOAL = 155;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_func);

        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Create and set up the DividerWeightDecoration
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(),
                LinearLayoutManager.VERTICAL);
        recyclerView.addItemDecoration(dividerItemDecoration);

        updateWeightList();

        Button addItemButton = findViewById(R.id.btnAddItem);
        addItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(weight_track.this, activity_weight_edit.class);
            startActivity(intent);
        });

        // Initialize the Switch and set up the listener
        smsSwitch = findViewById(R.id.switch1);
        smsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // isChecked will be true if the switch is in the On position
            if (isChecked) {
                checkForSmsPermission();
            }
        });
    }

    private void updateWeightList() {
        List<Weight> weightList = db.getAllWeight();
        if (weightAdapter == null) {
            weightAdapter = new WeightAdapter(weightList, this, this);
            recyclerView.setAdapter(weightAdapter);
        } else {
            weightAdapter = new WeightAdapter(weightList, this, this);
            recyclerView.swapAdapter(weightAdapter, false);
        }
    }

    @Override
    public void onItemClick(Weight weight) {
        Intent intent = new Intent(weight_track.this, activity_weight_edit.class);
        intent.putExtra("DATE", weight.getDate());
        intent.putExtra("WEIGHT", weight.getWeight());
        intent.putExtra("GOAL", weight.getGoal());
        startActivity(intent);
    }

    @Override
    public void onItemDelete(Weight weight, int position) {
        // Delete the weight from the database
        db.deleteWeight(weight);
        // Update the adapter
        weightAdapter.removeItem(position);

        // After deleting, check if the product quantity is low and send an SMS notification
        if (weight.getGoal() <= YOUR_GOAL) {
            sendGoalSms(weight);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateWeightList();
        // Check inventory levels after updating the list
        checkInventoryLevels();
    }

    private void checkInventoryLevels() {
        List<Weight> weightList = db.getAllWeight();
        for (Weight weight : weightList) {
            if (weight.getGoal() <= YOUR_GOAL) {
                sendGoalSms(weight);
            }
        }
    }

    private void checkForSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_SEND_SMS);
        } else {
            sendSmsMessage();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSmsMessage();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_LONG).show();

            }
        }
    }

    private void sendSmsMessage() {
        String phoneNumber = "1234567890"; // Dummy number for testing
        String message = "This is a test SMS message.";

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(getApplicationContext(), "SMS sent.", Toast.LENGTH_LONG).show();
                Log.d("SMS_TEST", "SMS sent to " + phoneNumber + ": " + message);
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "Sending SMS failed (simulated).", Toast.LENGTH_LONG).show();
                Log.e("SMS_TEST", "SMS sending failed", e);
            }
        } else {
            Log.d("SMS_TEST", "SMS permission not granted.");
            // Permission not granted, request it
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_SEND_SMS);
        }
    }

    private void sendGoalSms(Weight weight) {
        // Only attempt to send an SMS if the switch is on
        if (smsSwitch.isChecked()) {
            String phoneNumber = "1234567890"; // Replace with an appropriate number
            String message = "Your Alert for meeting your Goal " + weight.getWeight() + "! YOU DID IT! " + weight.getGoal() + " Congratulations!.";

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_SEND_SMS);
            } else {
                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                    Toast.makeText(getApplicationContext(),  "Your Alert for meeting your Goal "  + weight.getWeight() + "! YOU DID IT! " + weight.getGoal() + " Congratulations!", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Sending SMS failed.", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        } else {
            // The switch is off, do not send SMS
            Toast.makeText(this, "SMS notification is disabled", Toast.LENGTH_SHORT).show();
        }
    }
}