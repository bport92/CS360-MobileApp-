package com.weightenabler;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightDatabase";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_WEIGHT = "Weight";
    private static final String TABLE_USERS = "users";

    private static final String KEY_ID = "id";
    private static final String KEY_DATE = "Date";
    private static final String KEY_WEIGHT = "Weight";
    private static final String KEY_GOAL = "Goal";

    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_PHONE = "phone";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_WEIGHT_TABLE = "CREATE TABLE " + TABLE_WEIGHT + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_DATE + " TEXT,"
                + KEY_WEIGHT + " TEXT,"
                + KEY_GOAL + " INTEGER" + ")";
        db.execSQL(CREATE_WEIGHT_TABLE);

        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + KEY_USERNAME + " TEXT PRIMARY KEY,"
                + KEY_PASSWORD + " TEXT,"
                + KEY_PHONE + " TEXT" + ")";
        db.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // CRUD operations (create, read, update, delete)
    public void addWeight(Weight weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_DATE, weight.getDate());
        values.put(KEY_WEIGHT, weight.getWeight());
        values.put(KEY_GOAL, weight.getGoal());

        db.insert(TABLE_WEIGHT, null, values);
        db.close();
    }

    public Weight getWeight(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_WEIGHT, new String[] { KEY_ID,
                        KEY_DATE, KEY_WEIGHT, KEY_GOAL }, KEY_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        assert cursor != null;
        Weight weight = new Weight(
                cursor.getString(1), // Date
                cursor.getString(2), // Weight
                cursor.getInt(3)); // Users Goal
        cursor.close();
        db.close(); // Close the database connection
        return weight;
    }

    public List<Weight> getAllWeight() {
        List<Weight> weightList = new ArrayList<>();
        String selectQuery = "SELECT  * FROM " + TABLE_WEIGHT;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                int dateIndex = cursor.getColumnIndex(KEY_DATE);
                int weightIndex = cursor.getColumnIndex(KEY_WEIGHT);
                int goalIndex = cursor.getColumnIndex(KEY_GOAL);

                if (dateIndex != -1 && weightIndex != -1 && goalIndex != -1) {
                    String date = cursor.getString(dateIndex);
                    String weightValue = cursor.getString(weightIndex);
                    int goal = cursor.getInt(goalIndex);

                    Weight weight = new Weight(date, weightValue, goal);
                    weightList.add(weight);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close(); // Close the database connection

        return weightList;
    }

    public void updateWeight(Weight weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_DATE, weight.getDate());
        values.put(KEY_WEIGHT, weight.getWeight());
        values.put(KEY_GOAL, weight.getGoal());

        // Updating weight by date
        db.update(TABLE_WEIGHT, values, KEY_DATE + " = ?",
                new String[]{String.valueOf(weight.getDate())});
        db.close();
    }

    public boolean checkWeightExists(String weight) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_WEIGHT,
                new String[]{KEY_DATE},
                KEY_DATE + "=?",
                new String[]{weight}, null, null, null);
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        db.close(); // Close the database connection
        return exists;
    }

    public void deleteWeight(Weight weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WEIGHT, KEY_DATE + " = ?", new String[] { weight.getDate() });
        db.close();
    }

    public void addUser(String username, String password, String phone) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_USERNAME, username);
        values.put(KEY_PASSWORD, password);
        values.put(KEY_PHONE, phone);
        db.insert(TABLE_USERS, null, values);
        db.close();
    }

    public boolean checkUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{KEY_USERNAME},
                KEY_USERNAME + "=?", new String[]{username}, null, null, null);
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        db.close(); // Close the database connection
        return exists;
    }

    public boolean checkPhoneExists(String phone) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{KEY_PHONE},
                KEY_PHONE + "=?", new String[]{phone}, null, null, null);
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        db.close(); // Close the database connection
        return exists;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[] { KEY_USERNAME, KEY_PASSWORD },
                KEY_USERNAME + "=?", new String[] { username }, null, null, null);

        if (cursor != null && cursor.moveToFirst() && cursor.getCount() > 0) {
            @SuppressLint("Range") String storedPassword = cursor.getString(cursor.getColumnIndex(KEY_PASSWORD));
            cursor.close();
            db.close(); // Close the database connection
            return password.equals(storedPassword);
        }
        if (cursor != null) {
            cursor.close();
        }
        db.close(); // Close the database connection
        return false;
    }
}