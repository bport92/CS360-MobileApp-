package com.weightenabler;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
public class createAccount extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private EditText editTextPhone;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        usernameEditText = findViewById(R.id.CreateUser);
        passwordEditText = findViewById(R.id.CreatePass);
        editTextPhone = findViewById(R.id.editTextPhone);
        Button createAccountButton = findViewById(R.id.createAccountButton);
        db = new DatabaseHelper(this);

        createAccountButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            String phone = editTextPhone.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty() || phone.isEmpty()) {
                Toast.makeText(createAccount.this, "Please fill all fields", Toast.LENGTH_LONG).show();
                return;
            }

            if (db.checkUsernameExists(username)) {
                Toast.makeText(createAccount.this, "Username already exists", Toast.LENGTH_LONG).show();
                return;
            }

            if (db.checkPhoneExists(phone)) {
                Toast.makeText(createAccount.this, "Phone number already registered", Toast.LENGTH_LONG).show();
                return;
            }

            db.addUser(username, password, phone);
            Toast.makeText(createAccount.this, "User registered successfully", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(createAccount.this, Login.class);
            startActivity(intent);
        });
    }
}