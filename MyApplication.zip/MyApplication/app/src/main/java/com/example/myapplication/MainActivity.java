package com.example.myapplication;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText nameText;
    TextView textGreeting;
    Button buttonSayHello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nameText = findViewById(R.id.editTextText);
        textGreeting = findViewById(R.id.textView);
        buttonSayHello = findViewById(R.id.buttonSayHello);

        nameText.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
                buttonSayHello.setEnabled(!s.toString().isEmpty());
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            public void onTextChanged(CharSequence s, int start, int before, int count) {}
        });
    }

    public void SayHello(View view) {
        String name = nameText.getText().toString();

        if (!name.isEmpty()) {
            textGreeting.setText("Hello " + name);
        } else {
            textGreeting.setText("You must enter a name");
        }
    }
}